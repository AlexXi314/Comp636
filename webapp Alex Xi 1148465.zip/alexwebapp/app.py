from flask import Flask
from flask import render_template
from flask import request
from flask import redirect
from flask import url_for
import psycopg2
import connect
import uuid

dbconn = None

app = Flask(__name__)

def getCursor():
    global dbconn
    if dbconn == None:
        conn = psycopg2.connect(dbname=connect.dbname, user=connect.dbuser, password=connect.dbpass, host=connect.dbhost, port=connect.dbport)
        conn.autocommit = True
        dbconn = conn.cursor()
        return dbconn
    else:
        return dbconn
        
@app.route("/")
def home():
    cur = getCursor()
    cur.execute("select * from member;")
    select_result = cur.fetchall()
    column_names=[desc[0] for desc in cur.description]
    print(f"{column_names}")
    print(f"{select_result[0]}")
    return render_template('memberlist.html', dbresult=select_result, dbcols=column_names[1:])

@app.route("/member", methods=['GET']) 
def AdultOrYoung():
    global familyname
    memberid = request.args.get("memberID") 
    print(memberid) 
    cur = getCursor()
    cur.execute("select adultleader from member where memberid =%s", (memberid,)) 
    select_result = cur.fetchall(); 
    youngOrAdult = select_result[0][0]
    
    if(youngOrAdult == False):     
        ################# Young member, going to interface 1 
        cur = getCursor()
        cur.execute("select an.activitynightid, an.nighttitle, at.attendancestatus from attendance at \
        inner join activitynight an \
        on at.activitynightid = an.activitynightid \
        inner join member m \
        on at.memberid = m.memberid where m.memberid =%s", (memberid,))
        youngMember = cur.fetchall(); 
        print(youngMember)
        column_names=[desc[0] for desc in cur.description]
        cur = getCursor()
        cur.execute("select familyname, firstname from member where memberid =%s", (memberid,))
        membername = cur.fetchall()
        return render_template('young.html', dbname=membername, dbresult=youngMember, dbcols=column_names[1:])
    else:                       
        ################# Adult member, going to interface 2
        cur = getCursor()
        cur.execute("select adultleader from member where memberid =%s", (memberid,))
        adultMember = cur.fetchall(); 
        return render_template("adult.html", familyname = familyname)

    


